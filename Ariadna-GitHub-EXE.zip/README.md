# Ariadna — Windows EXE

This repository builds Ariadna as a portable Windows `.exe` using GitHub Actions. The build runs on a GitHub-hosted Windows machine; you do not need to install Node.js, Electron, or a compiler on your own PC.

## Build the EXE

1. Create a repository on GitHub. A private repository is recommended.
2. Upload the **contents** of this folder to the repository root (so `.github`, `desktop`, and `src` are at the top level).
3. Open the repository's **Actions** tab.
4. Select **Build Ariadna for Windows**.
5. Click **Run workflow** and confirm.
6. Wait for the run to finish successfully, open that run, and download the artifact named **Ariadna-Windows-EXE** from the Artifacts section.
7. Extract the downloaded ZIP. It contains `Ariadna.exe`.

You can also trigger a build by pushing a commit to the `main` or `master` branch, or by pushing a version tag such as `v3.0.1`.

## Project layout

- `src/index.html` — application interface and client-side logic.
- `desktop/main.js` — Electron main process.
- `desktop/preload.js` — restricted bridge between the app and Electron.
- `desktop/package.json` — Electron and portable Windows packaging configuration.
- `.github/workflows/build.yml` — automated Windows EXE build.
- `android/` — Android project configuration (not built by the Windows workflow).

## Notes

- The output is a portable Windows x64 executable; it does not create an installer.
- The first GitHub build downloads Electron and packaging tools, so it may take several minutes.
- Windows SmartScreen may show an unknown-publisher warning because the EXE is not code-signed. Only run builds from a repository you control and trust.
- Do not commit private signing keys, API secrets, or license private keys. Review any payment/contact details in `src/index.html` before publishing the repository.
