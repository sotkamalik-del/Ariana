const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ariadna', { fetch: (u) => ipcRenderer.invoke('ariadna-fetch', u) });
