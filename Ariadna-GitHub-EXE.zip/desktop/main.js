const { app, BrowserWindow, shell, ipcMain } = require('electron');
const path = require('path');
// Запросы автопроверки идут из главного процесса: без CORS и без отключения защиты окна.
ipcMain.handle('ariadna-fetch', async (e, url) => {
  if (new URL(url).protocol !== 'https:') throw new Error('https only');
  const r = await fetch(url, { signal: AbortSignal.timeout(9000), headers: { 'User-Agent': 'Ariadna/1.1' } });
  return { s: r.status, x: await r.text() };
});
app.whenReady().then(() => {
  const w = new BrowserWindow({ width: 520, height: 900, autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  w.loadFile('index.html');
  const ext = (u) => { if (/^(https?|viber):/i.test(u)) shell.openExternal(u); };
  w.webContents.setWindowOpenHandler(({ url }) => { ext(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (ev, url) => { if (!url.startsWith('file:')) { ev.preventDefault(); ext(url); } });
});
app.on('window-all-closed', () => app.quit());
